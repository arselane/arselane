import React from "react"
import ReactDOM from "react-dom"

export default function Interests(){
    return (
        <div className="text">
            <h3>Interests</h3>
            <p>
                Calisthenics, yoga, streching and meditation, I'm verry interested in human well-being and how to improve your brain and your body 💪.<br/><br/>
                I'm not a food expert but I like to cook some healthy meals, even if some of my desserts are not sugar free 😜.
            </p>
        </div>
    )
}