import React from "react"
import ReactDOM from "react-dom"

export default function Footer(){
    return(
        <div className="footer">
            <a href="https://twitter.com/arslnyto" targer="_blank"><img src="../src/images/twitter.png" /></a>
            <a href="https://www.facebook.com/arslane.hadjeus/" targer="_blank"><img src="../src/images/facebook.png" /></a>
            <a href="https://www.instagram.com/arslnyto/" targer="_blank"><img src="../src/images/instagram.png" /></a>
            <a href="https://www.linkedin.com/in/arselane-hadjeres-2859b7175/" targer="_blank"><img src="../src/images/linkedin.png" /></a>
            <a href="https://www.linkedin.com/in/arselane-hadjeres-2859b7175/" targer="_blank"><img src="../src/images/github.png" /></a>
        </div>
    )
}