import React from "react"
import ReactDOM from "react-dom"

export default function About(){
    return(
        <div className="text">
            <h3>About</h3>
            <p>
                Hi, I'm a frontend developer who've just started his React journey and this is my first project.<br/><br/>
                Always looking for new things to learn, feel free to give me advices, I'll really appreciate your experience sharing 🙏.
            </p>
        </div>
    )
}