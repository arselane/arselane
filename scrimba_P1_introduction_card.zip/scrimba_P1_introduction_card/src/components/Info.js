import React from "react"
import ReactDOM from "react-dom"

export default function Info(){
    return (
        <div>
            <img src="../src/images/pp.jpg" className="pp"/>
            <div className="info-wrapper">
                <h3>Arselane HADJERES</h3>
                <p>Frotend Developper</p>
                <button onClick={() => window.location = 'mailto:arselane.hadjeres@gmail.com'}>Email</button>
            </div>
        </div>
    )
}